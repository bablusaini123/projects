import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { Copy, Award, User, DollarSign, LogOut, Link as LinkIcon, Wallet, History, Users, X, Check } from 'lucide-react';
import toast, { Toaster } from 'react-hot-toast';
import PropTypes from 'prop-types';
import { getCurrentUser, getWithdrawHistory, logout } from './auth';
import axios from 'axios';
import {
  Drawer,
  DrawerClose,
  DrawerContent,
  DrawerDescription,
  DrawerFooter,
  DrawerHeader,
  DrawerTitle,
  DrawerTrigger,
} from "@/components/ui/drawer";
import { Button } from './ui/button';

const API_BASE_URL = 'http://localhost:5000';


const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

const fetchDashboardInfo = async (userId, referCode) => {
  if (!userId || !referCode) {
    throw new Error('Missing userId or referCode');
  }

  try {
    const response = await api.get('/dashBoardInfo', {
      params: { userId, referCode },
    });

    const now = new Date();
    const nextMidnight = new Date(now);
    nextMidnight.setHours(24, 0, 0, 0);
    const expirationTime = nextMidnight.getTime();

    localStorage.setItem('dashboardData', JSON.stringify({
      data: response.data,
      timestamp: now.toISOString(),
      expiresAt: expirationTime,
    }));

    return response.data;
  } catch (error) {
    console.error('API Error:', {
      message: error.message,
      status: error.response?.status,
      data: error.response?.data,
    });
    throw new Error(error.response?.data?.message || 'Failed to fetch dashboard data');
  }
};

const submitWithdrawalRequest = async ( userId,amount, paymentMethod, paymentDetails, password) => {
  try {
    
    const response = await api.post('/withdrawFunds', {
      userId:userId,
      amount,
      paymentMethod,
      paymentDetails,
      password
    });
    localStorage.setItem('withdrawalHistory', JSON.stringify(response.data.withdrawalHistory))
    return response.data;
  } catch (error) {
    console.error('Withdrawal API Error:', {
      message: error.message,
      status: error.response?.status,
      data: error.response?.data,
    });
    throw new Error(error.response?.data?.message || 'Failed to submit withdrawal request');
  }
};



const BonusCard = ({ bonusLevel, amount, invitees, rechargePerPerson, inviteesProgress, depositProgress }) => {
  const isCompleted = inviteesProgress === invitees && depositProgress === invitees;

  return (
    <div className="bg-gray-100 rounded-lg p-4 mb-4 text-black">
      <div className="flex items-center justify-between mb-2 ">
        <div className="flex items-center bg-green-600 px-3 py-2 rounded-tl-2xl rounded-br-2xl">
          <span className="bg-green-600 text-white rounded-full px-2 py-1 text-xs font-semibold mr-2">Bonus {bonusLevel}</span>
          {
            isCompleted &&
            <div className='flex gap-6'>
              <span className="text-green-600 text-md rounded-[50%] p-1 bg-white "><Check size={14} /></span>
            </div>
          }
          {!isCompleted && <span className="text-red-600 text-md rounded-[50%] p-1 bg-white"><X size={14} /></span>}
        </div>
        <span className="text-lg font-bold">₹{amount.toLocaleString()}</span>
      </div>
      <div className="text-sm space-y-1">
        <div className="flex justify-between">
          <span>Number of invites</span>
          <span>{inviteesProgress}/{invitees}</span>
        </div>
        <div className="flex justify-between">
          <span>Number Course Purchased</span>
          <span>{depositProgress}/{invitees}</span>
        </div>
      </div>
      <button
        className={`w-full ${isCompleted ? 'bg-gradient-to-r from-blue-600 to-red-500' : 'bg-gradient-to-r from-blue-200 to-red-300'} text-white py-2 rounded-lg mt-4 hover:bg-gray-700 transition-colors disabled:bg-gray-500 disabled:cursor-not-allowed`}
        disabled={!isCompleted}
      >
        {isCompleted ? 'Received' : 'Unfinished'}
      </button>
    </div>
  );
};

BonusCard.propTypes = {
  bonusLevel: PropTypes.number.isRequired,
  amount: PropTypes.number.isRequired,
  invitees: PropTypes.number.isRequired,
  rechargePerPerson: PropTypes.number.isRequired,
  inviteesProgress: PropTypes.number.isRequired,
  depositProgress: PropTypes.number.isRequired,
};

const Dashboard = () => {
  const navigate = useNavigate();
  const currentUser = useMemo(() => getCurrentUser(), []);
  const withdrawalHistory = useMemo(() => getWithdrawHistory(), []);
  

  const [dashboardState, setDashboardState] = useState({
    walletBalance: { balance: 0, lastUpdated: null },
    paymentHistory: [],
    referrals: { level1: [], level1Count: 0, level2Count: 0 },
    dashboardData: null,
    isLoading: true,
  });
  const [paymentMethod, setPaymentMethod] = useState("");
  const [withdrawAmount, setWithdrawAmount] = useState("");
  const [upiId, setUpiId] = useState("");
  const [accountHolderName, setAccountHolderName] = useState("");
  const [accountNumber, setAccountNumber] = useState("");
  const [ifscCode, setIfscCode] = useState("");
  const [password, setPassword] = useState("");

  const { walletBalance, paymentHistory, referrals, dashboardData } = dashboardState;
  const hasFetchedData = useRef(false);
  const abortControllerRef = useRef(null);
  const midnightLogoutTimerRef = useRef(null);

  const getMillisecondsUntilMidnight = useCallback(() => {
    const now = new Date();
    const nextMidnight = new Date(now);
    nextMidnight.setHours(24, 0, 0, 0);
    return nextMidnight.getTime() - now.getTime();
  }, []);
   

  const setupMidnightLogout = useCallback(() => {
    if (midnightLogoutTimerRef.current) {
      clearTimeout(midnightLogoutTimerRef.current);
    }

    const msUntilMidnight = getMillisecondsUntilMidnight();

    midnightLogoutTimerRef.current = setTimeout(() => {
      console.log('🌙 Midnight logout triggered - clearing session...');
      localStorage.clear();
      logout();
      toast.success('Daily session expired - logged out automatically!');
      navigate('/login');
    }, msUntilMidnight);

    const nextMidnight = new Date(Date.now() + msUntilMidnight);
    console.log(`🌙 Midnight logout scheduled for: ${nextMidnight.toLocaleString()}`);
    const hours = Math.floor(msUntilMidnight / (1000 * 60 * 60));
    const minutes = Math.floor((msUntilMidnight % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((msUntilMidnight % (1000 * 60)) / 1000);
    console.log(`⏰ Time until midnight logout: ${hours}h ${minutes}m ${seconds}s`);
  }, [navigate, getMillisecondsUntilMidnight]);

  const cleanupMidnightLogout = useCallback(() => {
    if (midnightLogoutTimerRef.current) {
      clearTimeout(midnightLogoutTimerRef.current);
      midnightLogoutTimerRef.current = null;
      console.log('🛑 Midnight logout timer cleared');
    }
  }, []);

  const fetchData = useCallback(async () => {
    if (hasFetchedData.current || !currentUser) return;

    const cachedData = localStorage.getItem('dashboardData');
    if (cachedData) {
      try {
        const { data, timestamp, expiresAt } = JSON.parse(cachedData);
        const now = Date.now();

        if (now < expiresAt) {
          const timeLeft = expiresAt - now;
          const hours = Math.floor(timeLeft / (1000 * 60 * 60));
          const minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
          const seconds = Math.floor((timeLeft % (1000 * 60)) / 1000);
          console.log(`⏳ Cache expires in: ${hours}h ${minutes}m ${seconds}s (at midnight)`);

          hasFetchedData.current = true;

          setDashboardState({
            walletBalance: { balance: data.totalEarning || 0, lastUpdated: new Date().toISOString() },
            paymentHistory: data.commissionHistory?.map((entry) => ({
              id: `${entry.date}-${entry.buyerName}`,
              date: entry.date,
              buyerName: entry.buyerName,
              courseTitle: entry.courseTitle,
              amount: entry.commission,
              commission: entry.commission,
            })) || [],
            referrals: {
              level1: data.directSubnets?.map((name, index) => ({
                id: `subnet-${index}`,
                email: name,
                referrals: 0,
              })) || [],
              level1Count: data.directSubnets?.length || 0,
              level2Count: data.teamSubnetCount || 0,
            },
            dashboardData: data,
            isLoading: false,
          });

          return;
        }

        console.log('🗑️ Cache expired (past midnight). Removing from localStorage.');
        localStorage.removeItem('dashboardData');

      } catch (err) {
        console.error('Error parsing cache:', err);
        localStorage.removeItem('dashboardData');
      }
    }

    if (abortControllerRef.current) abortControllerRef.current.abort();
    abortControllerRef.current = new AbortController();
    hasFetchedData.current = true;

    try {
      const timeoutPromise = (promise, ms) =>
        Promise.race([
          promise,
          new Promise((_, reject) => setTimeout(() => reject(new Error('Request timed out')), ms)),
        ]);

      const data = await timeoutPromise(
        fetchDashboardInfo(currentUser._id, currentUser.referCode),
        5000
      );

      if (!abortControllerRef.current?.signal.aborted) {
        setDashboardState({
          walletBalance: { balance: data.totalEarning || 0, lastUpdated: new Date().toISOString() },
          paymentHistory: data.commissionHistory?.map((entry) => ({
            id: `${entry.date}-${entry.buyerName}`,
            date: entry.date,
            buyerName: entry.buyerName,
            courseTitle: entry.courseTitle,
            amount: entry.commission,
            commission: entry.commission,
          })) || [],
          referrals: {
            level1: data.directSubnets?.map((name, index) => ({
              id: `subnet-${index}`,
              email: name,
              referrals: 0,
            })) || [],
            level1Count: data.directSubnets?.length || 0,
            level2Count: data.teamSubnetCount || 0,
          },
          dashboardData: data,
          isLoading: false,
        });
      }
    } catch (error) {
      if (!abortControllerRef.current?.signal.aborted) {
        console.error('Fetch Data Error:', error.message);
        toast.error(`Failed to load data: ${error.message}`);
        setDashboardState({
          walletBalance: { balance: 0, lastUpdated: null },
          paymentHistory: [],
          referrals: { level1: [], level1Count: 0, level2Count: 0 },
          dashboardData: null,
          isLoading: false,
        });
      }
    }
  }, [currentUser]);

  useEffect(() => {
    if (!currentUser) {
      navigate('/login');
      return;
    }

    fetchData();
    setupMidnightLogout();

    return () => {
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }
      cleanupMidnightLogout();
      hasFetchedData.current = false;
    };
  }, [currentUser, navigate, fetchData, setupMidnightLogout, cleanupMidnightLogout]);

  const handleLogout = useCallback(() => {
    cleanupMidnightLogout();
    logout();
    localStorage.removeItem('dashboardData');
    localStorage.removeItem('landingDashboardData');
    navigate('/login');
    toast.success('Logged out successfully!');
  }, [navigate, cleanupMidnightLogout]);

  const handleWithdraw = useCallback(async () => {
    const userId = JSON.parse(localStorage.getItem('currentUser'))
    if (!userId?._id) {
      toast.error('User not found. Please log in again.');
      return;
    }

    const amount = parseFloat(withdrawAmount);
    if (isNaN(amount) || amount <= 0) {
      toast.error('Please enter a valid amount.');
      return;
    }


    if (!paymentMethod) {
      toast.error('Please select a payment method.');
      return;
    }

    if (!password) {
      toast.error('Please enter your password.');
      return;
    }

    let paymentDetails = {};
    if (paymentMethod === 'upi') {
      if (!upiId) {
        toast.error('Please enter your UPI ID.');
        return;
      }
      paymentDetails = { upiId };
    } else if (paymentMethod === 'bank') {
      if (!accountHolderName || !accountNumber || !ifscCode) {
        toast.error('Please fill in all bank details.');
        return;
      }
      paymentDetails = { accountHolderName, accountNumber, ifscCode };
    }

    try {
      await submitWithdrawalRequest(userId._id, amount, paymentMethod, paymentDetails, password);
      toast.success('Withdrawal request submitted! Check your email for details.');
      setWithdrawAmount("");
      setUpiId("");
      setAccountHolderName("");
      setAccountNumber("");
      setIfscCode("");
      setPassword("");
      // Optionally refresh dashboard data
      hasFetchedData.current = false;
      await fetchData();
    } catch (error) {
      toast.error(error.message);
    }
  }, [currentUser, withdrawAmount, paymentMethod, upiId, accountHolderName, accountNumber, ifscCode, password, fetchData]);

  const getBadge = useCallback((level) => {
    const profileLevel = parseInt(level, 10) || 1;
    switch (profileLevel) {
      case 6: return { level: 6, name: 'Platinum Pro', color: 'from-purple-600 to-purple-800', icon: '🏆' };
      case 5: return { level: 5, name: 'Platinum', color: 'from-teal-500 to-teal-700', icon: '🌟' };
      case 4: return { level: 4, name: 'Diamond', color: 'from-blue-600 to-blue-800', icon: '💎' };
      case 3: return { level: 3, name: 'Gold', color: 'from-yellow-500 to-yellow-700', icon: '🥇' };
      case 2: return { level: 2, name: 'Silver', color: 'from-gray-400 to-gray-600', icon: '🥈' };
      default: return { level: 1, name: 'Bronze', color: 'from-orange-500 to-orange-700', icon: '🥉' };
    }
  }, []);

  const badge = getBadge(currentUser?.profileLevel);
  const referralCode = currentUser?.referCode || `https://skillearn.com/ref/${currentUser?.email || 'user'}`;

  const copyReferralLink = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(referralCode);
      toast.success('Referral code copied!');
    } catch (err) {
      console.error('Clipboard API error:', err);
      const textArea = document.createElement('textarea');
      textArea.value = referralCode;
      document.body.appendChild(textArea);
      textArea.select();
      try {
        document.execCommand('copy');
        toast.success('Referral code copied!');
      } catch (fallbackErr) {
        console.error('Fallback copy error:', fallbackErr);
        toast.error('Failed to copy referral code. Please copy manually.');
      } finally {
        document.body.removeChild(textArea);
      }
    }
  }, [referralCode]);

  // Bonus data with initial values
  const initialBonusData = [
    { level: 1, amount: 155.00, invitees: 2, rechargePerPerson: 500.00, inviteesProgress: 0, depositProgress: 0 },
    { level: 2, amount: 555.00, invitees: 10, rechargePerPerson: 500.00, inviteesProgress: 0, depositProgress: 0 },
    { level: 3, amount: 1555.00, invitees: 30, rechargePerPerson: 500.00, inviteesProgress: 0, depositProgress: 0 },
    { level: 4, amount: 3555.00, invitees: 70, rechargePerPerson: 500.00, inviteesProgress: 0, depositProgress: 0 },
    { level: 5, amount: 10955.00, invitees: 200, rechargePerPerson: 500.00, inviteesProgress: 0, depositProgress: 0 },
    { level: 6, amount: 25555.00, invitees: 500, rechargePerPerson: 500.00, inviteesProgress: 0, depositProgress: 0 },
    { level: 7, amount: 48555.00, invitees: 1000, rechargePerPerson: 500.00, inviteesProgress: 0, depositProgress: 0 },
    { level: 8, amount: 355555.00, invitees: 5000, rechargePerPerson: 500.00, inviteesProgress: 0, depositProgress: 0 },
    { level: 9, amount: 755555.00, invitees: 10000, rechargePerPerson: 500.00, inviteesProgress: 0, depositProgress: 0 },
    { level: 10, amount: 1555555.00, invitees: 20000, rechargePerPerson: 500.00, inviteesProgress: 0, depositProgress: 0 },
  ];

  // Calculate updated bonus data based on dashboardData
  const bonusData = useMemo(() => {
    if (!dashboardData) return initialBonusData;

    const { directSubnets = [], directSubnetsPurchaseCount = 0 } = dashboardData;
    const totalInvites = directSubnets.length || 0;
    const totalPurchases = directSubnetsPurchaseCount || 0;
    let remainingInvites = totalInvites;
    let remainingPurchases = totalPurchases;

    return initialBonusData.map((bonus, index) => {
      if (index === 0) {
        // Level 1: Complete if invites meet or exceed requirement
        const inviteesProgress = Math.min(remainingInvites, bonus.invitees);
        const depositProgress = Math.min(remainingPurchases, inviteesProgress);
        remainingInvites = Math.max(0, remainingInvites - inviteesProgress);
        remainingPurchases = Math.max(0, remainingPurchases - depositProgress);
        return {
          ...bonus,
          inviteesProgress,
          depositProgress,
        };
      } else {
        // For all other levels: Show total invites and purchases
        return {
          ...bonus,
          inviteesProgress: totalInvites,
          depositProgress: totalPurchases,
        };
      }
    });
  }, [dashboardData, initialBonusData]);

  if (dashboardState.isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-red-50 overflow-x-hidden">
        <div className="text-center">
          <div className="w-12 h-12 sm:w-16 sm:h-16 mx-auto bg-gradient-to-r from-blue-600 to-red-500 rounded-full animate-spin flex items-center justify-center">
            <div className="w-8 h-8 sm:w-12 sm:h-12 bg-white rounded-full"></div>
          </div>
          <p className="mt-4 text-lg sm:text-xl font-semibold text-gray-600 animate-pulse">Loading your dashboard...</p>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-6 grid grid-cols-1 gap-6">
            <div className="bg-white rounded-2xl shadow-lg p-4 animate-pulse">
              <div className="h-5 bg-gray-200 rounded w-1/3 mb-4"></div>
              <div className="h-20 bg-gray-200 rounded"></div>
            </div>
            <div className="bg-white rounded-2xl shadow-lg p-4 animate-pulse">
              <div className="h-5 bg-gray-200 rounded w-1/3 mb-4"></div>
              <div className="space-y-3">
                <div className="h-3 bg-gray-200 rounded"></div>
                <div className="h-3 bg-gray-200 rounded"></div>
                <div className="h-3 bg-gray-200 rounded"></div>
              </div>
            </div>
            <div className="bg-white rounded-2xl shadow-lg p-4 animate-pulse">
              <div className="h-5 bg-gray-200 rounded w-1/3 mb-4"></div>
              <div className="h-20 bg-gray-200 rounded"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="min-h-screen w-full bg-gradient-to-br from-blue-50 to-red-50 font-['Outfit'] py-6 overflow-x-hidden">
        <Toaster />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-6">
            <div id="wallet" className="sm:col-span-2 lg:col-span-2 bg-white rounded-2xl shadow-lg p-4 sm:p-6 hover:shadow-xl transition-all duration-300 w-full">
              <div className="flex items-center mb-4 gap-2">
                <Wallet className="w-6 h-6 sm:w-8 sm:h-8 text-blue-600 -mr-1 sm:mr-3" aria-hidden="true" />
                <h2 className="text-xl sm:text-2xl font-bold">Wallet</h2>
              </div>
              <div className="text-center p-4 sm:p-6 bg-gradient-to-br from-blue-50 to-red-50 rounded-lg mb-4">
                <div className="text-[20px] font-medium sm:text-4xl text-blue-600">
                  ₹{currentUser?.userWallet.toLocaleString()}
                </div>
                <div className="text-sm sm:text-base text-gray-600 mt-1">
                  Total Earnings
                </div>
              </div>
              <p className="text-sm sm:text-base text-gray-700 mb-4">
                This wallet shows your earnings from referrals. Withdraw funds after reaching the minimum limit.
              </p>
              <div className='flex gap-2'>
                <button
                  className="w-full bg-gradient-to-r from-blue-600 to-red-500 text-white px-4 py-2 sm:px-6 sm:py-3 rounded-lg font-semibold hover:shadow-lg transition-all duration-300 text-sm sm:text-base"
                  aria-label="Withdraw Funds"
                >
                  <Drawer>
                    <DrawerTrigger asChild>
                      <button
                        className="w-full bg-gradient-to-r from-blue-600 to-red-500 text-white px-0 py-0 sm:px-6 sm:py-3 rounded-lg font-semibold hover:shadow-lg transition-all duration-300 text-sm sm:text-base"
                        aria-label="Withdraw Funds"
                      >
                        Withdraw Funds
                      </button>
                    </DrawerTrigger>
                    <DrawerContent className="h-[99%] max-h-[99%] overflow-y-auto bg-gradient-to-br from-blue-50 to-red-50 text-white p-0">
                      <DrawerHeader>
                        <DrawerTitle className="text-xl font-bold text-black">Withdraw Funds</DrawerTitle>
                        <DrawerDescription className="text-gray-600">Enter your withdrawal details below</DrawerDescription>
                      </DrawerHeader>

                      <div className="px-4 pb-4 space-y-4">
                        {/* Amount Input */}
                        <div>
                          <label className="block text-sm font-medium text-black">Amount</label>
                          <input
                            type="number"
                            placeholder="Enter amount"
                            value={withdrawAmount}
                            onChange={(e) => setWithdrawAmount(e.target.value)}
                            className="mt-1 w-full px-4 py-2 rounded-md border border-gray-300 text-black focus:outline-none focus:ring-2 focus:ring-blue-500"
                          />
                        </div>

                        {/* Payment Method */}
                        <div>
                          <label className="block text-sm font-medium text-black">Payment Method</label>
                          <select
                            value={paymentMethod}
                            onChange={(e) => setPaymentMethod(e.target.value)}
                            className="mt-1 w-full px-4 py-2 rounded-md border border-gray-300 text-black focus:outline-none focus:ring-2 focus:ring-blue-500 overflow-hidden"
                          >
                            <option value="">Select Method</option>
                            <option value="upi">UPI</option>
                            <option value="bank">Bank Transfer</option>
                          </select>
                        </div>

                        {/* Conditional Fields based on Payment Method */}
                        {paymentMethod === "upi" && (
                          <div>
                            <label className="block text-sm font-medium text-black">Enter your UPI ID</label>
                            <input
                              type="text"
                              placeholder="e.g. yourname@upi"
                              value={upiId}
                              onChange={(e) => setUpiId(e.target.value)}
                              className="mt-1 w-full px-4 py-2 rounded-md border border-gray-300 text-black focus:outline-none focus:ring-2 focus:ring-blue-500"
                            />
                          </div>
                        )}

                        {paymentMethod === "bank" && (
                          <>
                            <div>
                              <label className="block text-sm font-medium text-black">Account Holder Name</label>
                              <input
                                type="text"
                                placeholder="Full name"
                                value={accountHolderName}
                                onChange={(e) => setAccountHolderName(e.target.value)}
                                className="mt-1 w-full px-4 py-2 rounded-md border border-gray-300 text-black focus:outline-none focus:ring-2 focus:ring-blue-500"
                              />
                            </div>
                            <div>
                              <label className="block text-sm font-medium text-black">Account Number</label>
                              <input
                                type="text"
                                placeholder="1234567890"
                                value={accountNumber}
                                onChange={(e) => setAccountNumber(e.target.value)}
                                className="mt-1 w-full px-4 py-2 rounded-md border border-gray-300 text-black focus:outline-none focus:ring-2 focus:ring-blue-500"
                              />
                            </div>
                            <div>
                              <label className="block text-sm font-medium text-black">IFSC Code</label>
                              <input
                                type="text"
                                placeholder="SBIN0001234"
                                value={ifscCode}
                                onChange={(e) => setIfscCode(e.target.value)}
                                className="mt-1 w-full px-4 py-2 rounded-md border border-gray-300 text-black focus:outline-none focus:ring-2 focus:ring-blue-500"
                              />
                            </div>
                          </>
                        )}

                        {/* Password */}
                        <div>
                          <label className="block text-sm font-medium text-black">Your Account's password</label>
                          <input
                            type="password"
                            placeholder="Enter your password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className="mt-1 w-full px-4 py-2 rounded-md border border-gray-300 text-black focus:outline-none focus:ring-2 focus:ring-blue-500"
                          />
                        </div>

                        {/* Submit Button */}
                        <div>
                          <button
                            onClick={handleWithdraw}
                            className="w-full bg-gradient-to-r from-blue-600 to-red-500 text-white py-2 px-4 rounded-md font-semibold transition"
                          >
                            Submit Withdrawal Request
                          </button>
                        </div>
                      </div>

                      <DrawerFooter className="mt-4">
                        <DrawerClose asChild>
                          <Button variant="outline" className="w-full bg-[#000] hover:bg-black hover:text-white text-white">
                            Cancel
                          </Button>
                        </DrawerClose>
                      </DrawerFooter>
                    </DrawerContent>
                  </Drawer>
                </button>
                <Drawer>
                  <DrawerTrigger asChild>
                    <button
                      className="w-full bg-gradient-to-r from-blue-600 to-red-500 text-white px-4 py-2 sm:px-6 sm:py-3 rounded-lg font-semibold hover:shadow-lg transition-all duration-300 text-sm sm:text-base"
                      aria-label="Invitation Bonus"
                    >
                      Invitation Bonus
                    </button>
                  </DrawerTrigger>
                  <DrawerContent className="h-[99%] max-h-[99%] overflow-y-auto bg-gradient-to-br from-blue-50 to-red-50 text-white p-0">
                    <DrawerHeader>
                      <DrawerTitle className="text-xl font-bold text-black">Invitation Bonus</DrawerTitle>
                      <DrawerDescription className="text-gray-600">View your invitation bonus progress</DrawerDescription>
                    </DrawerHeader>
                    <div className="mt-0">
                      {bonusData.map((bonus) => (
                        <BonusCard
                          key={bonus.level}
                          bonusLevel={bonus.level}
                          amount={bonus.amount}
                          invitees={bonus.invitees}
                          rechargePerPerson={bonus.rechargePerPerson}
                          inviteesProgress={bonus.inviteesProgress}
                          depositProgress={bonus.depositProgress}
                        />
                      ))}
                    </div>
                    <DrawerFooter className="mt-4">
                      <DrawerClose asChild>
                        <Button variant="outline" className="w-full bg-[#000] hover:bg-black hover:text-white text-white">
                          Cancel
                        </Button>
                      </DrawerClose>
                    </DrawerFooter>
                  </DrawerContent>
                </Drawer>
              </div>
            </div>

            <div className="sm:col-span-2 lg:col-span-3 bg-white rounded-2xl shadow-lg p-4 sm:p-6 hover:shadow-xl transition-all duration-300 w-full">
              <div className="flex items-center mb-4">
                <DollarSign className="w-6 h-6 sm:w-8 sm:h-8 text-blue-600 mr-2 sm:mr-3" aria-hidden="true" />
                <h2 className="text-xl sm:text-2xl font-bold">Earnings Overview</h2>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
                <div className="text-center p-3 sm:p-4 bg-gradient-to-br from-blue-50 to-red-50 rounded-lg">
                  <div className="text-[16px] sm:text-3xl font-normal text-blue-600">
                    ₹{walletBalance.balance.toLocaleString()}
                  </div>
                  <div className="text-xs sm:text-sm text-gray-600">Total Earnings</div>
                </div>
                <div className="text-center p-3 sm:p-4 bg-gradient-to-br from-blue-50 to-red-50 rounded-lg">
                  <div className="text-[16px] sm:text-3xl font-normal text-red-600">
                    ₹{(dashboardData?.monthlyEarning || 0).toLocaleString()}
                  </div>
                  <div className="text-xs sm:text-sm text-gray-600">Monthly Earnings</div>
                </div>
                <div className="text-center p-3 sm:p-4 bg-gradient-to-br from-blue-50 to-red-50 rounded-lg">
                  <div className="text-[16px] sm:text-3xl font-normal text-red-600">
                    ₹{(dashboardData?.yesterdayEarning || 0).toLocaleString()}
                  </div>
                  <div className="text-xs sm:text-sm text-gray-600">Yesterday Earnings</div>
                </div>
                <div className="text-center p-3 sm:p-4 bg-gradient-to-br from-blue-50 to-red-50 rounded-lg">
                  <div className="text-[16px] sm:text-3xl font-normal text-red-600">
                    ₹{(dashboardData?.todayEarning || 0).toLocaleString()}
                  </div>
                  <div className="text-xs sm:text-sm text-gray-600">Today Earnings</div>
                </div>
              </div>
            </div>

            <div id='affiliate' className="sm:col-span-2 lg:col-span-3 bg-white rounded-2xl shadow-lg p-4 sm:p-6 hover:shadow-xl transition-all duration-300 w-full">
              <div className="flex items-center mb-4">
                <Users className="w-6 h-6 sm:w-8 sm:h-8 text-blue-600 mr-2 sm:mr-3" aria-hidden="true" />
                <h2 className="text-xl sm:text-2xl font-bold">Referral Network</h2>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-2 gap-4 sm:gap-6 mb-4 sm:mb-6">
                <div className="text-center p-3 sm:p-4 bg-gradient-to-br from-blue-50 to-red-50 rounded-lg">
                  <div className="text-[17px] sm:text-3xl font-normal text-blue-600">{referrals.level1Count}</div>
                  <div className="text-xs sm:text-sm text-gray-600">Direct Referrals</div>
                </div>
                <div className="text-center p-3 sm:p-4 bg-gradient-to-br from-blue-50 to-red-50 rounded-lg">
                  <div className="text-[17px] sm:text-3xl font-normal text-red-600">{referrals.level2Count}</div>
                  <div className="text-xs sm:text-sm text-gray-600">Indirect Referrals</div>
                </div>
              </div>
              <div className="overflow-x-auto overflow-y-scroll max-h-[170px]">
                <table className="min-w-full text-left border-collapse text-xs sm:text-sm">
                  <thead>
                    <tr className="bg-gray-100">
                      <th className="p-2 sm:p-3 text-gray-700 font-semibold">Name</th>
                      <th className="p-2 sm:p-3 text-gray-700 font-semibold">Level</th>
                    </tr>
                  </thead>
                  <tbody>
                    {referrals.level1.slice(0, 5).map((ref) => (
                      <tr key={ref.id} className="border-t hover:bg-gray-50">
                        <td className="p-2 sm:p-3 text-gray-600 truncate max-w-[120px] sm:max-w-[200px]">{ref.email}</td>
                        <td className="p-2 sm:p-3 text-gray-600">Level 1</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {referrals.level1.length > 5 && (
                  <p className="mt-3 sm:mt-4 text-gray-600 text-xs sm:text-sm">
                    Showing 5 of {referrals.level1.length} referrals. Contact support for full list.
                  </p>
                )}
              </div>
            </div>

            <div className="overflow-x-auto w-full bg-white shadow-lg rounded-lg p-">
              <div className=" gap-1 p-2 sm:p-4 ">
                <div className="flex justify-start items-center p-2 sm:p-4 ">
                  <History className="w-6 h-6 sm:w-8 text-blue-600 mr-2 sm:mr-3" aria-hidden="true" />
                  <h2 className="text-xl sm:text-2xl font-bold ">Purchase History</h2>
                </div>
                <div className="overflow-x-auto overflow-y-scroll max-h-[170px]">
                  <table className="min-w-full text-left border-collapse text-xs sm:text-sm">
                    <thead>
                      <tr className="bg-gray-100">
                        <th className="p-2 sm:p-3 text-gray-700 font-semibold">Course Name</th>
                        <th className="p-2 sm:p-3 text-gray-700 font-semibold">Price</th>
                      </tr>
                    </thead>
                    <tbody>
                      {dashboardData?.purchaseHistory?.map((data, index) => (
                        <tr key={`${data.courseTitle}-${index}`} className="border-t hover:bg-gray-50 ">
                          <td className="p-2 sm:p-3 text-gray-600 truncate max-w-[120px] sm:max-w-[200px]">{data.courseTitle}</td>
                          <td className="p-2 sm:p-3 text-gray-600">₹{data.price.toLocaleString()}</td>
                        </tr>
                      )) || (
                          <tr>
                            <td colSpan="2" className="p-2 sm:p-3 text-center text-gray-600">
                              No purchase history available.
                            </td>
                          </tr>
                        )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            <div className="sm:col-span-2 lg:col-span-3 bg-white rounded-2xl shadow-lg p-4 sm:p-6 hover:shadow-xl transition-all duration-300 w-full">
              <div className="flex items-center mb-4">
                <History className="w-6 h-6 sm:w-8 sm:h-8 text-blue-600 mr-2 sm:mr-3" aria-hidden="true" />
                <h2 className="text-xl sm:text-2xl font-bold">Commission History</h2>
              </div>
              <div className="overflow-x-auto overflow-y-scroll max-h-[200px]">
                <table className="min-w-full text-left border-collapse text-xs sm:text-sm">
                  <thead>
                    <tr className="bg-gray-100">
                      <th className="p-2 sm:p-3 text-gray-700 font-semibold">Date</th>
                      <th className="p-2 sm:p-3 text-gray-700 font-semibold">Buyer Name</th>
                      <th className="p-2 sm:p-3 text-gray-700 font-semibold">Course</th>
                      <th className="p-2 sm:p-3 text-gray-700 font-semibold">Commission</th>
                    </tr>
                  </thead>
                  <tbody>
                    {paymentHistory.map((tx) => (
                      <tr key={tx.id} className="border-t hover:bg-gray-50">
                        <td className="p-2 sm:p-3 text-gray-600">{new Date(tx.date).toLocaleDateString()}</td>
                        <td className="p-2 sm:p-3 text-gray-600">{tx.buyerName}</td>
                        <td className="p-2 sm:p-3 text-gray-600 truncate max-w-[100px] sm:max-w-[150px]">{tx.courseTitle}</td>
                        <td className="p-2 sm:p-3 text-gray-600">₹{tx.commission.toLocaleString()}</td>
                      </tr>
                    ))}
                    {paymentHistory.length === 0 && (
                      <tr>
                        <td colSpan="4" className="p-2 sm:p-3 text-center text-gray-600">
                          No transactions yet.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
             <div className="sm:col-span-2 lg:col-span-3 bg-white rounded-2xl shadow-lg p-4 sm:p-6 hover:shadow-xl transition-all duration-300 w-full">
              <div className="flex items-center mb-4">
                <History className="w-6 h-6 sm:w-8 sm:h-8 text-blue-600 mr-2 sm:mr-3" aria-hidden="true" />
                <h2 className="text-xl sm:text-2xl font-bold">Commission History</h2>
              </div>
              <div className="overflow-x-auto overflow-y-scroll max-h-[200px]">
                <table className="min-w-full text-left border-collapse text-xs sm:text-sm">
                  <thead>
                    <tr className="bg-gray-100">
                      <th className="p-2 sm:p-3 text-gray-700 font-semibold">Date</th>
                      <th className="p-2 sm:p-3 text-gray-700 font-semibold">Payment Method</th>
                      <th className="p-2 sm:p-3 text-gray-700 font-semibold">Amount</th>
                      <th className="p-2 sm:p-3 text-gray-700 font-semibold">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    
                   
                  </tbody>
                </table>
              </div>
            </div>


            <div id='reffer' className="sm:col-span-2 lg:col-span-3 bg-white rounded-2xl shadow-lg p-4 sm:p-6 hover:shadow-xl transition-all duration-300 w-full flex gap-10 flex-wrap">
              <div className='flex flex-col w-full lg:w-[50%] justify-start p-4'>
                <div className="flex  flex-col items-center mb-4">
                  <LinkIcon className="w-7 h-6 sm:w-8 sm:h-8 text-blue-600 mr-2 sm:mr-3" aria-hidden="true" />
                  <h2 className="text-[12px] whitespace-break-spaces sm:text-2xl font-bold">Your Referral Code</h2>
                </div>
                <div className="w-full gap-3 sm:flex-row sm:items-center sm:gap-4">
                  <input
                    type="text"
                    value={referralCode}
                    readOnly
                    className="w-full p-2 sm:p-3 border border-gray-300 rounded-lg bg-gray-50 text-gray-600 text-sm sm:text-base"
                    aria-label="Referral Code"
                  />
                  <div className='w-full flex justify-center items-center mt-2 rounded-md bg-gradient-to-r from-blue-600 to-red-500'>
                    <button
                      onClick={copyReferralLink}
                      className="w-full sm:w-auto text-white px-2 py-2 sm:px-6 sm:py-3 rounded-lg font-semibold hover:shadow-lg transition-all duration-300 flex items-center justify-center text-sm sm:text-base whitespace-break-spaces"
                      aria-label="Copy Referral Code"
                    >
                      <Copy className="w-4 h-4 sm:w-5 sm:h-5 mr-1 sm:mr-2" aria-hidden="true" />
                      Copy Code
                    </button>
                  </div>
                </div>
                <p className="mt-3 sm:mt-4 text-gray-600 text-sm sm:text-base">
                  Share this code to earn up to ₹2800 per successful course purchase!
                </p>
              </div>
              <div className="bg-white rounded-2xl p-4 sm:p-6 hover:shadow-xl transition-all duration-300 w-full flex flex-col lg:w-[40%]">
                <div className="flex items-center mb-4">
                  <User className="w-6 h-6 sm:w-8 sm:h-8 text-red-500 mr-2 sm:mr-3" aria-hidden="true" />
                  <h2 className="text-[14px] whitespace-break-spaces sm:text-2xl font-bold">Profile Summary</h2>
                </div>
                <div className="space-y-3 sm:space-y-4">
                  <div>
                    <p className="text-gray-600 font-semibold text-sm sm:text-base">Name</p>
                    <p className="text-base sm:text-lg">{currentUser?.name || currentUser?.firstName || 'N/A'}</p>
                  </div>
                  <div>
                    <p className="text-gray-600 font-semibold text-sm sm:text-base">Email</p>
                    <p className="text-base sm:text-lg truncate">{currentUser?.email || 'N/A'}</p>
                  </div>
                  <div>
                    <p className="text-gray-600 font-semibold text-sm sm:text-base">Level</p>
                    <div className={`inline-flex items-center bg-gradient-to-r ${badge.color} text-white px-3 py-1 rounded-full text-xs sm:text-sm`}>
                      <Award className="w-4 h-4 sm:w-5 sm:h-5 mr-1 sm:mr-2" aria-hidden="true" />
                      {badge.name} (Level {badge.level})
                    </div>
                  </div>
                  <button
                    onClick={handleLogout} id='myButtonId'
                    className="w-full bg-gradient-to-r from-blue-600 to-red-500 text-white p-2 sm:p-3 rounded-lg flex items-center justify-center hover:bg-blue-600 transition-all duration-300 text-sm sm:text-base"
                    aria-label="Logout"
                  >
                    <LogOut className="w-4 h-4 sm:w-5 sm:h-5 mr-1 sm:mr-2" aria-hidden="true" />
                    Logout
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

Dashboard.propTypes = {};

export default Dashboard;