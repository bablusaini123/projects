import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CheckCircle, BookOpen } from 'lucide-react';
import '../App.css';

const SuccessPage = () => {
  const { state } = useLocation();
  const course = state?.course || null;
  const amount = state?.amount || 0;

  return (
    <div className="min-h-screen font-['Outfit'] bg-gradient-to-br from-blue-50 to-red-50 py-6 sm:py-10 overflow-x-hidden">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          className="text-center mb-12 sm:mb-16"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <CheckCircle className="w-12 h-12 sm:w-16 sm:h-16 text-green-500 mx-auto mb-4" aria-hidden="true" />
          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold mb-3 sm:mb-4">
            Payment Successful!
          </h1>
          <p className="text-lg sm:text-xl text-gray-600">
            Congratulations on your purchase! You're ready to start learning.
          </p>
        </motion.div>

        {course ? (
          <motion.div
            className="bg-white rounded-2xl shadow-lg p-6 sm:p-8 hover:shadow-xl transition-all duration-300"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <div className="flex flex-col sm:flex-row gap-6 sm:gap-8 items-center">
              <motion.img
                src={course.image}
                alt={course.title}
                className="w-full sm:w-48 h-32 sm:h-36 object-cover rounded-lg"
                whileHover={{ scale: 1.05 }}
                transition={{ duration: 0.3 }}
                loading="lazy"
              />
              <div className="flex-1 text-center sm:text-left">
                <h2 className="text-xl sm:text-2xl font-bold mb-2">{course.title}</h2>
                <p className="text-gray-600 mb-4 text-sm sm:text-base">
                  You've successfully purchased this course for{' '}
                  <span className="font-semibold text-blue-600">₹{amount.toLocaleString()}</span>.
                </p>
                <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center sm:justify-start">
                  <Link to="/dashboard">
                    <button
                      className="bg-gradient-to-r from-blue-600 to-red-500 text-white px-6 py-2 sm:px-8 sm:py-3 rounded-lg font-semibold hover:shadow-lg transition-all duration-300 text-sm sm:text-base"
                      aria-label="Go to Dashboard"
                    >
                      Go to Dashboard
                    </button>
                  </Link>
                  <Link to="/">
                    <button
                      className="border-2 border-blue-600 text-blue-600 px-6 py-2 sm:px-8 sm:py-3 rounded-lg font-semibold hover:bg-blue-600 hover:text-white transition-all duration-300 text-sm sm:text-base"
                      aria-label="Back to Home"
                    >
                      Back to Home
                    </button>
                  </Link>
                </div>
              </div>
            </div>
          </motion.div>
        ) : (
          <motion.div
            className="bg-white rounded-2xl shadow-lg p-6 sm:p-8 hover:shadow-xl transition-all duration-300 text-center"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <BookOpen className="w-12 h-12 sm:w-16 sm:h-16 text-blue-600 mx-auto mb-4" aria-hidden="true" />
            <h2 className="text-xl sm:text-2xl font-bold mb-2">Purchase Confirmed!</h2>
            <p className="text-gray-600 mb-4 text-sm sm:text-base">
              Your payment was successful, but course details are unavailable. Check your dashboard for access.
            </p>
            <Link to="/dashboard">
              <button
                className="bg-gradient-to-r from-blue-600 to-red-500 text-white px-6 py-2 sm:px-8 sm:py-3 rounded-lg font-semibold hover:shadow-lg transition-all duration-300 text-sm sm:text-base"
                aria-label="Go to Dashboard"
              >
                Go to Dashboard
              </button>
            </Link>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default SuccessPage;