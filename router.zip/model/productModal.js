// models/Product.js (Schema definition)
const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  title: String,
  brand: String,
  algorithm: String,
  coin: [String],
  mrp: String,
  sellPrice: String,
  productType: String,
  power: String,
  hashRate: String,
  overview: String,
  description: String,
  status:String,
  descriptionImage:{type:String,default:null},
  productImages:{type:Array,default:[]}


});

const Product = mongoose.model('Product', productSchema);

module.exports = Product;
